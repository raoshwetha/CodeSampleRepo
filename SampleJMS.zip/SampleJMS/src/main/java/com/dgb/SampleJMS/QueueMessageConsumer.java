package com.dgb.SampleJMS;

import javax.jms.ConnectionFactory;
import javax.jms.Connection;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class QueueMessageConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InitialContext intialContext = null;
		
		try{
						
			intialContext = new InitialContext();
			ConnectionFactory cf= (ConnectionFactory)intialContext.lookup("ConnectionFactory");
			Connection connection = cf.createConnection();
			Session session = connection.createSession();
			
			Queue testQ= (Queue) intialContext.lookup("queue/myQueue");
			
						
			// consume the message
			MessageConsumer consumer = session.createConsumer(testQ);
			connection.start();
			TextMessage receivedMessage = (TextMessage)consumer.receive(5000);
			System.out.println("Message Received : "+ receivedMessage.getText());
			
			
			
		} 
		catch(NamingException e){
			e.printStackTrace();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
