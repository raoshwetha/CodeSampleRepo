package com.dgb.SampleJMS;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.naming.InitialContext;
import javax.naming.NamingException;


public class TopicMessageProducer {

	public static void main(String[] args) throws NamingException, JMSException {

		InitialContext ic = new InitialContext();

		Topic topic = (Topic) ic.lookup("topic/myTopic");
		ConnectionFactory cf = (ConnectionFactory) ic.lookup("ConnectionFactory");
		Connection connection = cf.createConnection();

		Session session = connection.createSession();
		MessageProducer producer = session.createProducer(topic);
		TextMessage message = session.createTextMessage("HELLO, THIS IS A MESSAGE IN TOPIC");
		producer.send(message);
		System.out.println("MESSAGE SENT TO TOPIC");
		

		
		MessageConsumer consumer1 = session.createConsumer(topic);
		connection.start();
		TextMessage message1 = (TextMessage) consumer1.receive(5000);
		System.out.println("message 1:" + message1.getText());

		MessageConsumer consumer2 = session.createConsumer(topic);
		TextMessage message2 = (TextMessage) consumer2.receive(5000);
		System.out.println("message 2:" + message2.getText());
		
		ic.close(); connection.close();
	}

}
